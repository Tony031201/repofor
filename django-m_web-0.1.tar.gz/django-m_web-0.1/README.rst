============
django-m_web
============

django-m_web is a Django app to conduct a web-based publishing platform. Everyone can register an account here and publish their own zip files. In addition, they can download and comment on other people's files.

Detailed documentation is in the "docs" directory.

Quick start
-----------

1. Add "m_web" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...,
        "django_m_web",
    ]

2. Include the m_web URLconf in your project urls.py like this::

    path("polls/", include("django_m_web.urls")),

3. Run ``python manage.py migrate`` to create the models.

4. Start the development server and visit the admin to create a web.

5. Visit the ``/m_web/`` URL to participate in the poll.
