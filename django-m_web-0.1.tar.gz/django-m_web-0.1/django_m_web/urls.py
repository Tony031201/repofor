from django.urls import path,include
from . import views
from django.contrib.auth import views as auth_views


urlpatterns = [
    path("create_project_now/",views.create_project_now,name="create_project_now"),
    path("create_project/<int:person_id>/<int:user_id>",views.create_project,name="create_project"),
    path("update_person_now/",views.update_person_now, name="update_person_now"),
    path("update_person/<int:person_id>/",views.update_person, name="update_person"),
    path("create_person/",views.create_person, name="create_person"),
    path("create_card/",views.create_card, name="create_card"),
    path("register_view/",views.register_view, name="register_view"),
    path("logout/",views.log_out,name="logout"),
    path("user_index/<int:user_id>/",views.user_index, name="user_index"),
    path("accounts/login/", auth_views.LoginView.as_view(template_name="m_web/login.html"),name="login"),
    path("my_view/",views.my_view, name="my_view"),
    path("submit_comment/<int:doc_id>", views.comment_submit, name="submit"),
    path("personal/<int:person_id>", views.personal, name="personal"),
    path("download/<int:doc_id>/", views.download_file, name = "download"),
    path("index/<int:user_id>/<int:person_id>", views.index, name="index"),
    path("<int:doc_id>/", views.detail, name="detail"),
    path("comments_latest_order/",views.comment_latest_order,name="comment_latest_order"),
    path("comments_oldest_order/",views.comment_oldest_order,name="comment_oldest_order"),
]

