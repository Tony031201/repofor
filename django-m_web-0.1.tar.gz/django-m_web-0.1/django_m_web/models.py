from django.db import models
import datetime
from django.utils import timezone
import os
from django.shortcuts import get_object_or_404
from django.contrib.auth.models import Permission,User
from django.contrib.contenttypes.models import ContentType

def get_upload_path(instance, filename):
    return os.path.join('m_web/m_project', filename)

class Person(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    name= models.CharField(max_length=20)
    gender = models.CharField(max_length=10)
    birthday = models.DateField()
    email = models.CharField(max_length=50)
    phone = models.CharField(max_length=20)
    summary = models.CharField(max_length=1500)
    picture_url = models.CharField(max_length=500)

    def __str__(self):
        return self.name

    class Meta:
        permissions=[
            ("add_doc", "Add Doc"),
            ("add_context","Add Context"),
            ("add_comment","Add Comment"),
            ("change_doc", "Change Doc"),
            ("change_context", "Change Context"),
            ("delete_doc","Delete Doc"),
            ("delete_context", "Delete Context"),
        ]

class Superman(Person):
    class Meta:
        proxy=True
        permissions=[("add_person","Add Person")]

class Doc(models.Model):
    doc_title = models.CharField(max_length=200)
    pub_date = models.DateTimeField("date published")
    person = models.ForeignKey(Person,on_delete=models.CASCADE)

    def __str__(self):
        return self.doc_title

    def was_published_recently(self):
        return (timezone.now()-datetime.timedelta(days=30) <= self.pub_date <= timezone.now())

class Context(models.Model):
    doc = models.ForeignKey(Doc,on_delete=models.CASCADE)
    summary = models.CharField(max_length=500)
    detail = models.FileField(upload_to=get_upload_path)

    def __str__(self):
        return self.summary

class Comment(models.Model):
    editor = models.CharField(max_length=30)
    comment_text = models.CharField(max_length=1000)
    pub_date = models.DateTimeField("date published")
    context = models.ForeignKey(Context,on_delete=models.CASCADE)

    def __str__(self):
        return self.editor

    def was_published_recently(self):
        return (timezone.now()-datetime.timedelta(days=30) <= self.pub_date <= timezone.now())


def user_gains_perms(request, user_id):
    user = get_object_or_404(User, pk=user_id)
    # any permission check will cache the current set of permissions
    user.has_perm("m_web.change_person")

    content_type = ContentType.objects.get_for_model(Person)
    permission = Permission.objects.get(
        codename="change_person",
        content_type=content_type,

    )

    user.user_permission.add(permission)
    user.has_perm("m_web.change_person")

    user = get_object_or_404(User, pk=user_id)

    user.has_perm("m_web.change_person")

# Create your models here.
