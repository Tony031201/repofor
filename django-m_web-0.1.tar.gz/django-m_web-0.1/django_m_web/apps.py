from django.apps import AppConfig


class MWebConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_m_web'
    label="m_web"
