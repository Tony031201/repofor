from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse
from django.template import loader
from django.utils import timezone
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.hashers import make_password
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.core.validators import validate_email
from django.core.exceptions import ValidationError

from .models import Doc,Context,Comment,Person
import os

# Create your views here.

def index(request,user_id,person_id):
    if request.user.id != user_id:
        return HttpResponse("Page doesn't exist.")
    user=User.objects.get(pk=user_id)
    person=Person.objects.get(pk=person_id)

    if person.user != user:
        return HttpResponse("Page doesn't exist.")

    latest_doc_list = person.doc_set.order_by("-pub_date")[:50]
    context = {
        "person":person,
        "latest_doc_list": latest_doc_list,
        "user":user,
    }
    return render(request, "m_web/index.html", context)

def detail(request,doc_id):
    doc = get_object_or_404(Doc, pk=doc_id)
    contexts=doc.context_set.all()
    context=contexts[0]
    comments=context.comment_set.all()
    if request.user.is_authenticated:
        return render(request, "m_web/detail.html", {"doc": doc, "user":request.user, "comments":comments,})
    else:
        return render(request, "m_web/logout_detail.html", {"doc": doc, "user":request.user, "comments":comments,})

def comment_latest_order(request):
    doc = get_object_or_404(Doc, pk=request.POST["doc_id"])
    comments_id=request.POST.getlist("comments_id")
    comments=Comment.objects.filter(id__in=comments_id).order_by("-pub_date")
    if request.user.is_authenticated:
        return render(request, "m_web/detail.html", {"doc": doc, "user":request.user, "comments":comments,})
    else:
        return render(request, "m_web/logout_detail.html", {"doc": doc, "user":request.user, "comments":comments,})

def comment_oldest_order(request):
    doc = get_object_or_404(Doc, pk=request.POST["doc_id"])
    comments_id=request.POST.getlist("comments_id")
    comments=Comment.objects.filter(id__in=comments_id).order_by("pub_date")
    if request.user.is_authenticated:
        return render(request, "m_web/detail.html", {"doc": doc, "user":request.user, "comments":comments,})
    else:
        return render(request, "m_web/logout_detail.html", {"doc": doc, "user":request.user, "comments":comments,})



def download_file(request,doc_id):
    d = get_object_or_404(Doc, pk=doc_id)
    contexts = d.context_set.all()
    context = contexts[0]
    file_path = context.detail.name
    file_name = os.path.basename(file_path)
    with open(file_path, 'rb') as f:
        response = HttpResponse(f.read(), content_type='application/octet-stream')
        response['Content-Disposition'] = 'attachment; filename="{}"'.format(file_name)
        return response

def personal(request,person_id):
    person = Person.objects.get(pk=person_id)
    if request.user == person.user:
        belong=1
    else:
        belong=None

    return render(request, "m_web/personal.html", {"person":person, "user":request.user,"belong":belong,})

def comment_submit(request,doc_id):
    doc=get_object_or_404(Doc,pk=doc_id)
    contexts=doc.context_set.all()
    context=contexts[0]

    name=request.user.username
    if not name:
        name="Anonymous"
    comment=request.POST["comment"]
    if comment:
        context.comment_set.create(
            editor=name,
            comment_text=comment,
            pub_date=timezone.now(),
            context=context,
        )
        return redirect('detail',doc_id=doc.id)
    else:
        return render(request,"m_web/detail.html",{
            "doc":doc,
            "error_message":"Please submit valid comment.",
            "user": request.user,
            "comments":doc.context_set.first().comment_set.all(),
        })


def my_view(request):
    if request.method == "POST":
        try:
            username = request.POST["username"]
            password = request.POST["password"]
        except KeyError:
            return HttpResponse("Please provide both username and password.")

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request,user)
            return redirect('user_index',user_id=user.id)
        else:
            return render(request,"m_web/login.html",{
                "error_message":"Please enter correct password.",
                "user": request.user,
            })
    else:
        return HttpResponse("my_view error.")

@login_required(login_url="login")
def user_index(request,user_id):
    if request.user.id != user_id:
        return HttpResponse("Page doesn't exist.")
    user = User.objects.get(pk=user_id)
    return render(request,"m_web/user_index.html",{"user":user})
@login_required(login_url="login")
def log_out(request):
    logout(request)
    return redirect('login')

class Registration(UserCreationForm):
    email = forms.EmailField()


def register_view(request):
    if request.method=="POST":

        form= Registration(request.POST)
        if form.is_valid():
            username=form.cleaned_data["username"]
            email=form.cleaned_data["email"]
            password=form.cleaned_data['password1']
            confirm_password=form.cleaned_data['password2']
            if password != confirm_password:
                return HttpResponse("password doesn't match.")
            user=User.objects.create_user(username=username, email=email,password=password)
            if user:
                return redirect('login')
            else:
                return HttpResponse("register failed")
        else:
            return render(request,'m_web/register_user.html',{'form': form})
    else:
        form=Registration()
        return render(request,'m_web/register_user.html',{'form': form})
@login_required(login_url="login")
def create_card(request):
    return render(request,"m_web/create_person.html",)
@login_required(login_url="login")
def create_person(request):
    user=request.user
    if request.method=="POST":
        email=request.POST.get("email")
        try:
            validate_email(email)
        except ValidationError:
            return HttpResponse("Invalid email address.")
        name = request.POST.get('name')
        gender = request.POST.get('gender')
        birthday = request.POST.get('birthday')
        phone = request.POST.get('phone')
        summary = request.POST.get('summary')
        picture_url = request.POST.get('picture_url')
        if picture_url==None:
            picture_url='https://tse2.mm.bing.net/th?id=OIP.9dVuhFexwURDKZz0nB5UBAHaHa&pid=Api&P=0&h=180'
        person=Person.objects.create(
            user=request.user,
            name=name,
            gender=gender,
            birthday=birthday,
            email=email,
            phone=phone,
            summary=summary,
            picture_url=picture_url
        )

        if person:
            person.save()
            return redirect('user_index',user_id=user.id)
        else:
            return HttpResponse("Create person fail")
    else:
        return HttpResponse("Not get")
@login_required(login_url="login")
def update_person(request, person_id):
    person=get_object_or_404(Person,pk=person_id)

    if request.user != person.user:
        return HttpResponse("Personal card doesn't exist.")

    return render(request,"m_web/update_person.html",{"person_id":person_id,})
@login_required(login_url="login")
def update_person_now(request):
    user=request.user
    if request.method=="POST":
        person_id=request.POST.get("person_id")
        person=get_object_or_404(Person,pk=person_id)

        if user != person.user:
            return HttpResponse("update_person_now error.")

        email = request.POST.get("email")
        try:
            validate_email(email)
        except ValidationError:
            return HttpResponse("Invalid email address.")
        name = request.POST.get('name')
        gender = request.POST.get('gender')
        birthday = request.POST.get('birthday')
        phone = request.POST.get('phone')
        summary = request.POST.get('summary')
        picture_url = request.POST.get('picture_url')
        if picture_url == None:
            picture_url = 'https://tse2.mm.bing.net/th?id=OIP.9dVuhFexwURDKZz0nB5UBAHaHa&pid=Api&P=0&h=180'

        person.email = email
        person.name = name
        person.gender = gender
        person.birthday = birthday
        person.phone = phone
        person.summary = summary
        person.picture_url = picture_url

        person.save()

        return redirect('user_index',user_id=user.id)

    else:
        return HttpResponse("update person card error.")

@login_required(login_url="login")
def create_project(request,person_id,user_id):
    user=get_object_or_404(User,pk=user_id)
    if request.user != user:
        return HttpResponse("Page doesn't exist.")
    return render(request,"m_web/create_project.html",{"user_id":user.id,"person_id":person_id,})

@login_required(login_url="login")
def create_project_now(request):
    if request.method=="POST":
        user_id=request.POST.get("user_id")
        user=get_object_or_404(User,pk=user_id)
        person_id=request.POST.get("person_id")
        person=get_object_or_404(Person,pk=person_id)
        doc_title=request.POST.get("doc_title")
        summary=request.POST.get("summary")
        if 'detail' in request.FILES:
            uploaded_file = request.FILES['detail']
        else:
            return HttpResponse("there is no file upload")
        doc=Doc.objects.create(
            person=person,
            doc_title=doc_title,
            pub_date=timezone.now(),
        )
        if doc:
            doc.save()
        else:
            return HttpResponse("doc create fail.")

        context=Context.objects.create(
            doc=doc,
            summary=summary,
            detail=uploaded_file
        )

        if context:
            context.save()
            return redirect('index', user_id=user_id,person_id=person_id)
        else:
            return HttpResponse("context create failed")



    else:
        return HttpResponse("create_project_now ERROR.")