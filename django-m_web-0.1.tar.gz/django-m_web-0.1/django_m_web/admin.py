from django.contrib import admin
from .models import Doc,Context,Person,Comment
from django.contrib.auth.models import Permission,User


class DocInline(admin.StackedInline):
    model = Doc
    extra = 6

class CommentInline(admin.StackedInline):
    model=Comment
    extra = 6


class PersonAdmin(admin.ModelAdmin):
    fieldsets = [
        ("Basic information",{"fields":["name","gender","birthday","email","phone","picture_url"]}),
        ("Introduce",{"fields":["summary"],"classes":["collapse"]}),
    ]
    inlines=[DocInline]
    list_filter = ["name"]
    list_display = ["name","email"]

class ContextAdmin(admin.ModelAdmin):
    fieldsets = [
        (None,{"fields":["doc"]}),
        ("Detal",{"fields":["summary","detail"],"classes":["collapse"]}),
    ]
    inlines=[CommentInline]
    list_filter = ["doc"]
    list_display = ["doc","detail"]

class CommentAdmin(admin.ModelAdmin):
    fieldsets = [
        ("Basic information",{"fields":["editor","pub_date"]}),
        ("Detail",{"fields":["context","comment_text"],"classes":["collapse"]}),
    ]
    list_filter = ["pub_date","editor"]

admin.site.register(Context,ContextAdmin)
admin.site.register(Person,PersonAdmin)
admin.site.register(Comment,CommentAdmin)
admin.site.register(Doc)

# Register your models here.
