#include <stdio.h>
#include <pthread.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/time.h>
#include <time.h>
#include <sys/types.h>
#include <stdlib.h>

//train information
typedef struct Train{
	//number is train id
	int number;
	char direction;
	char priority;
	int loadingTime;
	int crossingTime;
} Train;

//Data required by the train thread
typedef struct ThreadArgs{
	Train* train;
	pthread_mutex_t* mutex;
	pthread_mutex_t* go_mutex;
	pthread_mutex_t* track;
	pthread_cond_t* ready;
	pthread_cond_t* condition;
	pthread_cond_t* track_ready;

	int* waitlist;
	int* waitlist_low;
	int* count;
	int* count_low;
	int* flag;
	int* flag_condiction;
	int* flag_clear;
	int* flag_ready;
	struct timespec* begin;
	struct timespec* end;
	FILE* file;
}ThreadArgs;

//Data required by the station thread
typedef struct Auto{
	pthread_t thread[100];
	ThreadArgs args[50];
	int trainCount;
}Auto;


//This function is used to monitor vehicles traveling in the same direction. 
//Whenever a train in the same direction continuously passes the track, the flag will be increased by one.
void flagControl(int* flag,char* lastdir,char* currentdir){
	if(*lastdir=='U'){
		*flag=*flag+1;
	}else if(toupper(*lastdir)==toupper(*currentdir)){
		*flag=*flag+1;
	}else{
		*flag=1;
	}

}

//This function is used to determine the sequence number of the next train entering the track. 
//This function will select the priority according to the rules in the pdf.
int chooseNextTrain(int* waitlist,int* count,Train* train,char* lastdir,pthread_mutex_t* mutex,int* flag){
	int chosenTrain=-1;
	pthread_mutex_lock(mutex);
	if(*count==1){
		chosenTrain=(*(waitlist));
		flagControl(flag,lastdir,&(train[chosenTrain].direction));	
		//Each time a train is returned, flagControl will be called to monitor 
		//the number of trains traveling in the same direction.
		*lastdir=train[chosenTrain].direction;
		*count=*count-1;
	}else if(*count>1){
		Train first=train[*(waitlist)];
		Train second=train[*(waitlist+1)];
		//SAME DIRECTION
		if(first.direction==second.direction){
			//SAME LOADING TIME
			if(first.loadingTime==second.loadingTime){
				//COMPARE NUMBER
				if(first.number<second.number){
					//When the first train has a smaller sequence number, 
					//select the first train
					chosenTrain=(*(waitlist));
					flagControl(flag,lastdir,&(first.direction));
					*lastdir=first.direction;
					for(int i=0;i<*count;i++){
						*(waitlist+i)=*(waitlist+i+1);
					}
					*count=*count-1;
				}else{
					//When the second train's sequence number is smaller, 
					//the second train is selected to enter the track.
					chosenTrain=(*(waitlist+1));
					flagControl(flag,lastdir,&(second.direction));
					*lastdir=second.direction;
					for(int i=1;i<*count;i++){
						*(waitlist+i)=*(waitlist+i+1);
					}
					*count=*count-1;
				}
			}else if(first.loadingTime<second.loadingTime){
				//When the loading times are inconsistent, 
				//select the train number that is loaded first.
				chosenTrain=(*(waitlist));
				flagControl(flag,lastdir,&(first.direction));
				*lastdir=first.direction;
				for(int i=0;i<*count;i++){
					*(waitlist+i)=*(waitlist+i+1);
				}
				*count=*count-1;
			}else{
				//opposite situation
				chosenTrain=(*(waitlist+1));
				flagControl(flag,lastdir,&(second.direction));
				*lastdir=second.direction;
				for(int i=1;i<*count;i++){
					*(waitlist+i)=*(waitlist+i+1);
				}
				*count=*count-1;
			}
		}else if(first.direction!=second.direction){
			//different direction
			//Direction-related priorities.
			if(first.direction!=*lastdir && *lastdir!='U'){
				chosenTrain=(*(waitlist));
				flagControl(flag,lastdir,&(first.direction));
				*lastdir=first.direction;
				for(int i=0;i<*count;i++){
					*(waitlist+i)=*(waitlist+i+1);
					}
				*count=*count-1;
			}else if(second.direction!=*lastdir && *lastdir!='U'){
				chosenTrain=(*(waitlist+1));
				flagControl(flag,lastdir,&(second.direction));
				*lastdir=second.direction;
				for(int i=1;i<*count;i++){
					*(waitlist+i)=*(waitlist+i+1);
				}
				*count=*count-1;
			}else{
				if(first.direction=='w'||first.direction=='W'){
					chosenTrain=(*(waitlist));
					flagControl(flag,lastdir,&(first.direction));
					*lastdir=first.direction;
					for(int i=0;i<*count;i++){
						*(waitlist+i)=*(waitlist+i+1);
					}
					*count=*count-1;
				}else{
					chosenTrain=(*(waitlist+1));
					flagControl(flag,lastdir,&(second.direction));
					*lastdir=second.direction;
					for(int i=1;i<*count;i++){
						*(waitlist+i)=*(waitlist+i+1);
					}
					*count=*count-1;
				}
			}
		}
	
	}
	pthread_mutex_unlock(mutex);
	return chosenTrain;
}

//Functions for train threads.
void* test(void* arg){ 

	ThreadArgs* ARG=(ThreadArgs*)arg;
	Train* train = (Train*)(ARG->train);
	long seconds;
	long nanoseconds;
	double elapsed;
	
	//The train starts loading
	char directionStr[5];
	if(train->direction=='e'||train->direction=='E'){
		strcpy(directionStr,"East");
	}else if(train->direction=='w'||train->direction=='W'){
		strcpy(directionStr,"West");
	}else{
		strcpy(directionStr,"unkn");
	}
	
	usleep((train->loadingTime)*100000);

	//finish loading and try to enter waitlist
	pthread_mutex_lock(ARG->mutex);
	//If the direction letter is uppercase, 
	//the train enters the high-priority queue.
	//Otherwise enter low-priority queue.
	if(isupper(train->direction)){
		*(ARG->waitlist+*(ARG->count))=train->number-1;
		*(ARG->count)=*(ARG->count)+1;
	}else if(islower(train->direction)){
		*(ARG->waitlist_low+*(ARG->count_low))=train->number-1;
		*(ARG->count_low)=*(ARG->count_low)+1;
	}else{
		perror("ERROR ON mutex");
	}

	//Record the time from the start of loading until entering the waiting list.
	//caculate it
	clock_gettime(CLOCK_MONOTONIC,ARG->end);
	seconds=(*(ARG->end)).tv_sec-(*(ARG->begin)).tv_sec;
	nanoseconds=(*(ARG->end)).tv_nsec-(*(ARG->begin)).tv_nsec;
	if(nanoseconds<0){
		seconds--;
		nanoseconds+=1000000000;
	}
	elapsed=(double)(seconds+(nanoseconds/1000000000.0));	
	printf("00:00:%04.1lf Train %2d is ready to go %4s\n",elapsed,train->number-1,directionStr);
	pthread_mutex_unlock(ARG->mutex);
	
	//Send a signal to inform the station that the train is officially waiting to depart.
	pthread_mutex_lock(ARG->go_mutex);
	pthread_cond_signal(ARG->ready);
	
	//Wait for the departure signal from the station.
	//If the train's departure signal is received, the train enters the track.
	pthread_cond_wait(ARG->condition,ARG->go_mutex);
	*(ARG->flag_condiction)=1;	//Inform the station that the train has received the departure signal and departed.
	pthread_mutex_unlock(ARG->go_mutex);

	//Enter the critical section. 
	//This symbolizes the train entering the track.
	pthread_mutex_lock(ARG->track);
	clock_gettime(CLOCK_MONOTONIC,ARG->end);
	seconds=(*(ARG->end)).tv_sec-(*(ARG->begin)).tv_sec;
	nanoseconds=(*(ARG->end)).tv_nsec-(*(ARG->begin)).tv_nsec;
	if(nanoseconds<0){
		seconds--;
		nanoseconds+=1000000000;
	}
	elapsed=(double)(seconds+(nanoseconds/1000000000.0));
	//Caculate and print departure time
	printf("00:00:%04.1lf Train %2d is ON the main track going %4s\n",elapsed,train->number-1,directionStr);

	usleep((train->crossingTime)*100000);

	clock_gettime(CLOCK_MONOTONIC,ARG->end);
	seconds=(*(ARG->end)).tv_sec-(*(ARG->begin)).tv_sec;
	nanoseconds=(*(ARG->end)).tv_nsec-(*(ARG->begin)).tv_nsec;
	if(nanoseconds<0){
		seconds--;
		nanoseconds+=1000000000;
	}
	elapsed=(double)(seconds+(nanoseconds/1000000000.0));
	//Caculate and print finish time
	//Send a signal to inform the station that the train has evacuated the track.
	printf("00:00:%04.1lf Train %2d is OFF the main track after going %4s\n",elapsed,train->number-1,directionStr);
	while(*(ARG->flag_clear)==0){
		pthread_cond_signal(ARG->track_ready); 
	}
	*(ARG->flag_clear)=0;
	pthread_mutex_unlock(ARG->track);
	
	//Thread ends
	pthread_exit(NULL);

}

//This function is used to automatically enter train information at the station.
void* autorecord(void* arg){
	Auto* ARG=(Auto*)arg;
	for(int i=6;i<ARG->trainCount;i++){
		pthread_create(&ARG->thread[i],NULL,test,&ARG->args[i]);
	}
}

int main(int argc,char *argv[]){
	char* filename= malloc((strlen(argv[1]) + 1) * sizeof(char));
	strcpy(filename,argv[1]);
	//Open the file and enter the train information.
	FILE *file=fopen(filename,"r");
	if (file == NULL){
		printf("ERROR open");
		return 1;
	}
	Train train[100];
	int trainCount = 0;
	Auto au;
	char direction;
	int loadingTime;
	int crossingTime;
	while(fscanf(file," %c %d %d",&direction,&loadingTime,&crossingTime)!=EOF){
		train[trainCount].direction=direction;
		train[trainCount].loadingTime=loadingTime;
		train[trainCount].crossingTime=crossingTime;
		
		
		train[trainCount].priority=train[trainCount].direction;
		train[trainCount].number=trainCount+1;
		trainCount++;
	}

	fclose(file);
	au.trainCount=trainCount;

	//create vraiables and mutex and condtion
	int* waitlist=malloc(100*sizeof(int));
	int* waitlist_low=malloc(100*sizeof(int));
	int flag=0;
	int flag_condiction=0;
	int flag_clear=0;
	int count=0;
	int count_low=0;
	int flag_ready=0;
	struct timespec begin,end;

	pthread_mutex_t mutex;
	pthread_mutex_t go_mutex;
	pthread_mutex_t track;
	pthread_cond_t ready;
	pthread_cond_t condictions[100];
	pthread_cond_t track_ready;

	//initial
	pthread_mutex_init(&mutex,NULL);
	pthread_mutex_init(&go_mutex,NULL);
	pthread_mutex_init(&track,NULL);
	pthread_cond_init(&ready,NULL);
	pthread_cond_init(&track_ready,NULL);
	pthread_mutex_t station2;
	pthread_mutex_init(&station2,NULL);

	pthread_t threads[100];
	for(int i=0;i<trainCount;i++){
		pthread_cond_init(&condictions[i],NULL);
	}
	
	ThreadArgs args[trainCount];
	for(int i=0;i<trainCount;i++){
		args[i].train=&train[i];
		args[i].waitlist=waitlist;
		args[i].waitlist_low=waitlist_low;
		args[i].count=&count;
		args[i].count_low=&count_low;
		args[i].mutex=&mutex;
		args[i].go_mutex=&go_mutex;
		args[i].ready=&ready;
		args[i].track_ready=&track_ready;
		args[i].condition=&condictions[i];
		args[i].flag=&flag;
		args[i].track=&track;
		args[i].flag_condiction=&flag_condiction;
		args[i].flag_clear=&flag_clear;
		args[i].flag_ready=&flag_ready;
		args[i].begin=&begin;
		args[i].end=&end;
		au.args[i]=args[i];
	}
	
	//Begin to record time
	//Create a thread for each train.
	clock_gettime(CLOCK_MONOTONIC,&begin);
	if(trainCount<7){
		for(int i=0;i<trainCount;i++){
			pthread_create(&threads[i],NULL,test,&args[i]);
		}
	}else{
		for(int i=0;i<6;i++){
			pthread_create(&threads[i],NULL,test,&args[i]);
		}
		pthread_create(&threads[95],NULL,autorecord,&au);
	}

	//station part
	pthread_mutex_t station;
	pthread_mutex_init(&station,NULL);
	pthread_mutex_lock(&station);
	pthread_cond_wait(&ready,&station);
	pthread_mutex_unlock(&station);

	//Initialize the variables needed by the station.
	int k=0;
	int chosenTrain;
	char lastdir='U';
	int chosen;
	int FLAG=0;
	while(k<trainCount){
		if(count>0&&FLAG<3){
			//Call the function to select the next train to depart.
			chosen=chooseNextTrain(waitlist,&count,train,&lastdir,&mutex,&FLAG);
		}else if(count_low>0&&FLAG<3){
			chosen=chooseNextTrain(waitlist_low,&count_low,train,&lastdir,&mutex,&FLAG);	
		}else if(FLAG>=3){
			//When a train in the same direction passes the main track three times in a row, 
			//the train in the opposite direction gets high priority.
			int m=0;
			int n=0;
			if(lastdir=='W'||lastdir=='w'){
				char searchdir='k';
				while(searchdir!='E'&& m<count){
					searchdir=train[*(waitlist+m)].direction;
					m++;
				}
				if(searchdir=='E'){
					m--;
					chosen=(*(waitlist+m));
					for(int j=m;j<count;j++){
						*(waitlist+j)=*(waitlist+j+1);
					}
					count--;
					FLAG=0;

				}else{
					while(searchdir!='e'&& n<count_low){
						searchdir=train[*(waitlist_low+n)].direction;
						n++;
					}
					if(searchdir=='e'){
						n--;
						chosen=(*(waitlist_low+n));
						for(int j=n;j<count_low;j++){
							*(waitlist_low+j)=*(waitlist_low+j+1);
						}
						count_low--;
						FLAG=0;
					}else{
						if(count>0){
							chosen=chooseNextTrain(waitlist,&count,train,&lastdir,&mutex,&FLAG);
						}else if(count_low>0){
							chosen=chooseNextTrain(waitlist_low,&count_low,train,&lastdir,&mutex,&FLAG);
						}
					}

				}
		}else if(lastdir=='e'||lastdir=='E'){
			char searchdir='k';
			while(searchdir!='W'&& m<count){
				searchdir=train[*(waitlist+m)].direction;
				m++;
			}
                                if(searchdir=='W'){
					m--;
					chosenTrain=(*(waitlist+m));
					for(int j=m;j<count;j++){
						*(waitlist+j)=*(waitlist+j+1);
					}
					count--;
					FLAG=0;
				}else{
					while(searchdir!='w'&& n<count_low){
						searchdir=train[*(waitlist+n)].direction;
						n++;
					}
					if(searchdir=='w'){
						n--;
						chosenTrain=(*(waitlist+n));
						for(int j=n;j<count_low;j++){
							*(waitlist+j)=*(waitlist+j+1);
						}
						count_low--;
						FLAG=0;
					}else{
						if(count>0){
							chosen=chooseNextTrain(waitlist,&count,train,&lastdir,&mutex,&FLAG);
						}else if(count_low>0){
							chosen=chooseNextTrain(waitlist_low,&count_low,train,&lastdir,&mutex,&FLAG);
						}
					}
				}
		}
		}
		//Send a departure signal to the train thread.
		while(flag_condiction==0){
			pthread_cond_signal(&condictions[chosen]);
		}
		flag_condiction=0;
		pthread_mutex_lock(&station2);
		//Wait for the track to clear before selecting the next train to depart.
		pthread_cond_wait(&track_ready,&station2);
		flag_clear=1;
		pthread_mutex_unlock(&station2);
		k++;
	}

	//free malloc
	free(waitlist);
	free(waitlist_low);
return 0;
}
