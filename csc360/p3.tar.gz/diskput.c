#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <time.h>
#include <arpa/inet.h>

typedef struct BlockInfo {
    int startBlock;
    int endBlock;
    char *subName;
    char *address;
} Block;

struct __attribute__((__packed__)) SuperBlock {
    uint8_t fsId[8];
    uint16_t blockSize;
    uint32_t fsBlockCount;
    uint32_t fatStartBlock;
    uint32_t fatBlockCount;
    uint32_t rootDirStartBlock;
    uint32_t rootDirBlockCount;
};

struct __attribute__((__packed__)) DirEntryTime {
    uint16_t year;
    uint8_t month;
    uint8_t day;
    uint8_t hour;
    uint8_t minute;
    uint8_t second;
};

struct __attribute__((__packed__)) DirEntry {
    uint8_t status;
    uint32_t startBlock;
    uint32_t blockCount;
    uint32_t size;
    struct DirEntryTime createTime;
    struct DirEntryTime modifyTime;
    uint8_t filename[31];
    uint8_t unused[6];
}DirEntry;

#define DIRECTORY_ENTRY_SIZE 64
int read_directory(void* address, int start_block, int num_blocks, int block_size, struct DirEntry *entries, int max_entries) {
	struct DirEntry* fp;
	// caculate the location of directory
	int offset = start_block * block_size;

	int num_entry = num_blocks * block_size / 64 ;
        int entries_read = 0;   // number of entries already read
	struct DirEntry *entry;

        for (int i = 0;i < num_entry && entries_read < max_entries;++i) {
                // read current block into buffer
                fp = ( struct DirEntry*)(address + offset + i*64);

		entry = &entries[entries_read];

		// Check the status and set accordingly
                if (fp->status == 3) {
			entry->status = 'F';	// Indicates a file
		} else if (fp->status == 5 || fp->status == 4){
			entry->status = 'D';	// Indicates a directory
		} else{continue;}

		// Convert network byte order to host byte order
		entry->startBlock = ntohl(fp->startBlock);
		entry->blockCount = ntohl(fp->blockCount);
		entry->size = ntohl(fp->size);
		// Copy time and filename information
		memcpy(&entry->createTime, &fp->createTime, sizeof(struct DirEntryTime));
		memcpy(&entry->modifyTime, &fp->modifyTime, sizeof(struct DirEntryTime));
		strncpy((char *)entry->filename, (char *)fp->filename, sizeof(entry->filename) - 1);
		entry->filename[sizeof(entry->filename) - 1] = '\0';
		memcpy(entry->unused, fp->unused, sizeof(entry->unused));
                entries_read++;
                
        }

        return entries_read;
}

// Function to find an open directory entry
int FindOpenDirEntry(int rootBlock, int blockSize, void* address) {
    for (int i = rootBlock; i < rootBlock + blockSize; i += 64) {
        int currentStatus = 0;
        memcpy(&currentStatus, address + i, 1);
        if (currentStatus == 0) {
            return i;	// Returns the offset of an open directory entry
        }
    }
    return -1;	// Indicates no open entry was found
}

// Function to fill a directory entry
void FillDirEntry(void* address, int entryOffset, int status, int startingBlock, int neededBlocks, int fileSize, struct tm* localTime, char* filePlacement) {
    int endOfFile = 0xFFFFFFFF;
    int endOfFileShort = 0xFFFF;

    // Convert values for network byte order
    int startBlockValue = ntohl(startingBlock);
    int neededBlocksValue = htonl(neededBlocks);
    int fileSizeValue = htonl(fileSize);

    // Copy values into the directory entry
    memcpy(address + entryOffset, &status, 1);
    memcpy(address + entryOffset + 1, &startBlockValue, 4);
    memcpy(address + entryOffset + 5, &neededBlocksValue, 4);
    memcpy(address + entryOffset + 9, &fileSizeValue, 4);

    int k;
    char timeBuffer[10];

    // Fill in time fields with formatted local time
    strftime(timeBuffer, sizeof(timeBuffer), "%Y", localTime);
    sscanf(timeBuffer, "%d", &k);
    k = htons(k);
    memcpy(address + entryOffset + 20, &k, 2);
    memcpy(address + entryOffset + 13, &k, 2);

    // ... Fill in other time fields ...
    strftime(timeBuffer, sizeof(timeBuffer), "%m", localTime);
    sscanf(timeBuffer, "%d", &k);
    memcpy(address + entryOffset + 22, &k, 1);
    memcpy(address + entryOffset + 15, &k, 1);

    strftime(timeBuffer, sizeof(timeBuffer), "%d", localTime);
    sscanf(timeBuffer, "%d", &k);
    memcpy(address + entryOffset + 23, &k, 1);
    memcpy(address + entryOffset + 16, &k, 1);

    strftime(timeBuffer, sizeof(timeBuffer), "%H", localTime);
    sscanf(timeBuffer, "%d", &k);
    memcpy(address + entryOffset + 24, &k, 1);
    memcpy(address + entryOffset + 17, &k, 1);

    strftime(timeBuffer, sizeof(timeBuffer), "%M", localTime);
    sscanf(timeBuffer, "%d", &k);
    memcpy(address + entryOffset + 25, &k, 1);
    memcpy(address + entryOffset + 18, &k, 1);

    strftime(timeBuffer, sizeof(timeBuffer), "%S", localTime);
    sscanf(timeBuffer, "%d", &k);
    memcpy(address + entryOffset + 26, &k, 1);
    memcpy(address + entryOffset + 19, &k, 1);

    strncpy(address + entryOffset + 27, filePlacement, 31);

    memcpy(address + entryOffset + 58, &endOfFile, 4);
    memcpy(address + entryOffset + 62, &endOfFileShort, 2);
}


// Function to add an entry to a directory
int AddEntryToDir(int rootBlock, int blockSize, void* address, struct stat fileStat, char* filePlacement, int fileSize, int neededBlocks, int startingBlock, int fatStartBlock, int fatDirLocation) {
    int status = 3;	// Status indicating a file
    int entryOffset = FindOpenDirEntry(rootBlock, blockSize, address);

    if (entryOffset != -1) {
        time_t rawTime;
        struct tm* localTime;

        time(&rawTime);
        localTime = localtime(&rawTime);

	// Filling the directory entry
        FillDirEntry(address, entryOffset, status, startingBlock, neededBlocks, fileSize, localTime, filePlacement);
        return 0;
    }

    return fatDirLocation;
}

// Function to add a subdirectory to a directory
int AddSubdirectoryToDir(int rootBlock, int blockSize, void* address, char* subdirectoryName, int startingBlock, int fatStartBlock, int fatDirLocation) {
	int status = 5;	// Status indicating a directory
	int entryOffset = FindOpenDirEntry(rootBlock, blockSize, address);

	if (entryOffset != -1) {
		time_t rawTime;
		struct tm* localTime;

		time(&rawTime);
		localTime = localtime(&rawTime);

		// Filling the directory entry for a subdirectory
		FillDirEntry(address, entryOffset, status, startingBlock, 1, 512, localTime, subdirectoryName);

		// Update FAT for the new subdirectory
		int fatEntry = htonl(startingBlock);
		memcpy(address + fatStartBlock + startingBlock * 4, &fatEntry, 4);
		return 0;
	}
	 return 1;	// Indicates failure to add subdirectory
}

int main(int argc, char *argv[]) {
    // Argument check
    if (argc != 4) {
        printf("Error: Incorrect usage. Requires 4 arguments\n");
        return 0;
    }

    // Define variables for the file name and file placement
    char *fileName;
    char *filePlacement;
    fileName = argv[2];
    filePlacement = argv[3];

    int fd = open(argv[1], O_RDWR);
    struct stat buffer;

    // Get the status of the file
    if (fstat(fd, &buffer) < 0) {
        perror("FSTAT ERROR");
        return 1;
    }

    struct stat fileStat;
    int fileDescriptor = open(fileName, O_RDONLY);

    if (fstat(fileDescriptor, &fileStat) < 0) {
        printf("File not found.\n");
        return 1;
    }

    char *directory[10];
    char *token = strtok(filePlacement, "/");
    int num_directory = 0;
    
    while (token != NULL) {
        directory[num_directory] = token;
        token = strtok(NULL, "/");
	num_directory++;
    }

    printf("Putting %s into %s as %s.\n", fileName, argv[1], directory[num_directory-1]);

    int fileSize = fileStat.st_size;
    close(fileDescriptor);

    FILE *filePointer;
    filePointer = fopen(fileName, "rb");

    void* address = mmap(NULL, buffer.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    struct SuperBlock* superBlock;
    superBlock = (struct SuperBlock*) address;

    // Retrieve block size and other filesystem information
    int blockSize = htons(superBlock->blockSize);
    int fatStartBlock = ntohl(superBlock->fatStartBlock) * blockSize;
    int fatBlockCount = ntohl(superBlock->fatBlockCount);
    int fatEndBlock = fatStartBlock + fatBlockCount * blockSize;
    int rootDirStartBlock = ntohl(superBlock->rootDirStartBlock) * blockSize;
    int num_bl = ntohl(superBlock->rootDirBlockCount);
    int neededBlocks = fileSize / blockSize;

    // Reading the directory entries
    struct DirEntry rootDirEntries[100];
    int numRootDirEntries = read_directory(address, rootDirStartBlock/blockSize, num_bl, blockSize, rootDirEntries, 100);
	
    // Looking for a specific subdirectory entry
    int subdirEntryIndex = -1;
    for (int i = 0; i < numRootDirEntries; i++) {
	    if (strcmp(rootDirEntries[i].filename, directory[0]) == 0 && rootDirEntries[i].status == 'D') {
		    subdirEntryIndex = i;
	
		    break;
	    }
    }

    // Additional logic to handle file size and allocate necessary blocks
    if (fileSize % blockSize != 0) {neededBlocks++;}

    int blocksUsed = 0;
    int end = 0xFFFFFFFF;
    int memLocation = 0, lastFAT = 0, startingBlock = 0;
    char fileBuffer[512];
    int i;

    // Loop to find free blocks and write data
    for (i = fatStartBlock; i < fatEndBlock; i += 4) {
        int current = -1;
        memcpy(&current, address + i, 4);
        current = htonl(current);

        if (current == 0) {
		// Logic to handle the first block and subsequent blocks
		// Includes reading data, copying to buffer, and updating FAT entries
            if (blocksUsed == 0) {
                startingBlock = (i - fatStartBlock) / 4;
                lastFAT = i;
                blocksUsed++;

                fread(fileBuffer, blockSize, 1, filePointer);
                memcpy(address + (startingBlock * blockSize), &fileBuffer, blockSize);
                continue;
            }

            memLocation = (i - fatStartBlock) / 4;
            fread(fileBuffer, blockSize, 1, filePointer);
            memcpy(address + (memLocation * blockSize), &fileBuffer, blockSize);

            int location = htonl(memLocation);
            memcpy(address + lastFAT, &location, 4);
            lastFAT = i;
            blocksUsed++;

            if (blocksUsed == neededBlocks) {
                memcpy(address + i, &end, 4);
                break;
            }
        }
    }

    int rootBlock = rootDirStartBlock;
    int fatDirLocation = 0;

    if (num_directory == 1) {
	printf("Under Root direcoty create file: %s\n", directory[0]);
    	fatDirLocation = AddEntryToDir(rootBlock, blockSize, address, fileStat, directory[0], fileSize, neededBlocks, startingBlock, fatStartBlock, fatDirLocation);
	fclose(filePointer);
        close(fd);
        close(fileDescriptor);
	return 0;
    }
	
    int memLocation2 = 0, lastFAT2 = 0, startingBlock2 = 0;
    int k = 0;
    if (num_directory != 1 && subdirEntryIndex == -1){
    	//not find
	for (k = fatStartBlock; k < fatEndBlock; k += 4) {
		int current = -1;
		memcpy(&current, address + k, 4);
		current = ntohl(current);
		startingBlock2 = (k - fatStartBlock) / 4;
		if (current == 0) {
			current = ntohl(current);
			lastFAT2 = k;
			break;
		    }
	    }
	printf("Under Root direcoty create directory: %s\n", directory[0]); 
	fatDirLocation = AddSubdirectoryToDir(rootBlock, blockSize, address, directory[0], startingBlock2, fatStartBlock, fatDirLocation);
	    
	numRootDirEntries = read_directory(address, rootDirStartBlock/blockSize, num_bl, blockSize, rootDirEntries, 100);

	    
	subdirEntryIndex = -1;
	    
	for (int i = 0; i < numRootDirEntries; i++) {
		if (strcmp(rootDirEntries[i].filename, directory[0]) == 0 && rootDirEntries[i].status == 'D') {
			subdirEntryIndex = i;
			break;
		
		}
	}

	    //
	    
	int F = 1;
	    
	while (1) {
	    	memLocation2 = 0;
                lastFAT2 = 0;
                startingBlock2 = 0;
                for (k = fatStartBlock; k < fatEndBlock; k += 4) {
                        int current = -1;
			startingBlock2 = (k-fatStartBlock)/4;
                        memcpy(&current, address + k, 4);
                        current = ntohl(current);

                         if (current == 0) {
                                current = ntohl(current);
                                lastFAT2 = k;
                                break;
                        }
                }

		printf("Under directory: %s create directory: %s\n",rootDirEntries[subdirEntryIndex].filename, directory[F]);
		fatDirLocation = AddSubdirectoryToDir(rootDirEntries[subdirEntryIndex].startBlock * blockSize, blockSize, address, directory[F], startingBlock2, fatStartBlock, fatDirLocation);

		numRootDirEntries = read_directory(address, rootDirEntries[subdirEntryIndex].startBlock, rootDirEntries[subdirEntryIndex].blockCount, blockSize, rootDirEntries, 100);

		subdirEntryIndex = 0;
		F++;
		if (F==num_directory-1) {break;}
	}
		
	printf("Under directory: %s create file: %s\n",rootDirEntries[0].filename, directory[F]);
	    
	fatDirLocation = AddEntryToDir(rootDirEntries[0].startBlock*blockSize, blockSize, address, fileStat, directory[F], fileSize, neededBlocks, startingBlock, fatStartBlock, fatDirLocation);
	
	fclose(filePointer);
        close(fd);
        close(fileDescriptor);
        return 0;
	
    }else if (num_directory != 1) {
    	// find
	if (num_directory > 2) {
        	int F = 1;
        	struct DirEntry old;
        	while (1) {
			old.startBlock = rootDirEntries[subdirEntryIndex].startBlock;
			old.blockCount = rootDirEntries[subdirEntryIndex].blockCount;
			old.size = rootDirEntries[subdirEntryIndex].size;
			memcpy(&old.createTime, &rootDirEntries[subdirEntryIndex].createTime, sizeof(struct DirEntryTime));
			memcpy(&old.modifyTime, &rootDirEntries[subdirEntryIndex].modifyTime, sizeof(struct DirEntryTime));
			strncpy((char *)old.filename, (char *)rootDirEntries[subdirEntryIndex].filename, sizeof(old.filename) - 1);
			old.filename[sizeof(old.filename) - 1] = '\0';
			memcpy(old.unused, rootDirEntries[subdirEntryIndex].unused, sizeof(old.unused));

            		numRootDirEntries = read_directory(address, rootDirEntries[subdirEntryIndex].startBlock, rootDirEntries[subdirEntryIndex].blockCount, blockSize, rootDirEntries, 100);

	    		subdirEntryIndex = -1;
            		for (int t=0;t < numRootDirEntries;t++) {
                		if(strcmp(directory[F],rootDirEntries[t].filename) == 0){
                        		subdirEntryIndex = t; 
                       			F++;
                		}
           	 	}
          
		if(subdirEntryIndex == -1){break;}
        }


        for(;F<num_directory-1;F++){
		memLocation2 = 0;
	    	lastFAT2 = 0; 
	    	startingBlock2 = 0;
		for (k = fatStartBlock; k < fatEndBlock; k += 4) {
			int current = -1;
			startingBlock2 = (k-fatStartBlock)/4;
			memcpy(&current, address + k, 4);
			current = ntohl(current);

			 if (current == 0) {
				current = ntohl(current);
				lastFAT2 = k;
				break;
			}	
		}
		printf("Under directory: %s create directory: %s\n",old.filename,directory[F]);
        	fatDirLocation = AddSubdirectoryToDir(old.startBlock*blockSize, blockSize, address, directory[F], startingBlock2, fatStartBlock, fatDirLocation);

		//search
		numRootDirEntries = read_directory(address, old.startBlock, old.blockCount, blockSize, rootDirEntries, 100);
		subdirEntryIndex = -1;
		for (int t=0;t < numRootDirEntries;t++) {
			if(strcmp(directory[F],rootDirEntries[t].filename) == 0){
				subdirEntryIndex = t;
			}
		}

		old.startBlock = rootDirEntries[subdirEntryIndex].startBlock;
        
		old.blockCount = rootDirEntries[subdirEntryIndex].blockCount;
            
		old.size = rootDirEntries[subdirEntryIndex].size;
            
		memcpy(&old.createTime, &rootDirEntries[subdirEntryIndex].createTime, sizeof(struct DirEntryTime));
            
		memcpy(&old.modifyTime, &rootDirEntries[subdirEntryIndex].modifyTime, sizeof(struct DirEntryTime));

		strncpy((char *)old.filename, (char *)rootDirEntries[subdirEntryIndex].filename, sizeof(old.filename) - 1);

		old.filename[sizeof(old.filename) - 1] = '\0';

		memcpy(old.unused, rootDirEntries[subdirEntryIndex].unused, sizeof(old.unused));

	}
		printf("Under directory: %s create file: %s\n",old.filename,directory[F]);
        	fatDirLocation = AddEntryToDir(old.startBlock*blockSize, blockSize, address, fileStat, directory[F], fileSize, neededBlocks, startingBlock, fatStartBlock, fatDirLocation);

	fclose(filePointer);
        close(fd);
        close(fileDescriptor);
        return 0;
}

	if (num_directory == 2){
	printf("Under directory: %s create file: %s\n", rootDirEntries[subdirEntryIndex].filename, directory[num_directory-1]);
	fatDirLocation = AddEntryToDir( rootDirEntries[subdirEntryIndex].startBlock*blockSize, blockSize, address, fileStat, directory[num_directory-1], fileSize, neededBlocks, startingBlock, fatStartBlock, fatDirLocation);}
    
	fclose(filePointer);
        close(fd);
        close(fileDescriptor);
	return 0;
    	}
    //AddSubdirectoryToDir(rootBlock, blockSize, address, directory, startingBlock, fatStartBlock, fatDirLocation);
    //fatDirLocation = AddEntryToDir(rootBlock, blockSize, address, fileStat, filename, fileSize, neededBlocks, startingBlock, fatStartBlock, fatDirLocation);


    	if (!fatDirLocation) {
		fclose(filePointer);
        	close(fd);
        	close(fileDescriptor);
        	return 0;
    	}

    	for (i = fatDirLocation; i < fatEndBlock; i += 4) {
        	int current = -1;
        	memcpy(&current, address + i, 4);
        	current = htonl(current);

        	if (current == 0) {
            		int newLocation = htonl((i - fatStartBlock) / 4);
            		memcpy(address + fatDirLocation, &newLocation, 4);

            
			memcpy(address + i, &end, 4);

            
			int rootBlocks = ntohl(superBlock->rootDirBlockCount) + 1;
			rootBlocks = ntohl(rootBlocks);
            		memcpy(address + 26, &rootBlocks, 4);
            		break;
     		}
    }

    //AddEntryToDir(rootBlock, blockSize, address, fileStat, filename, fileSize, neededBlocks, startingBlock, fatStartBlock, fatDirLocation);

    return 0;
}
