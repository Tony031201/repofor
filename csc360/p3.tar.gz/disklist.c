#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h> 

typedef struct __attribute__((__packed__)) DirectoryEntry {
	uint8_t status;
	uint32_t starting_block;
	uint32_t block_count;
	uint32_t file_size;
	uint8_t creation_time[7];
	uint8_t modify_time[7];
	uint8_t file_name[31];
	uint8_t unused[6];
		
}DirectoryEntry;

struct __attribute__((__packed__)) superblock {
	uint8_t filesystem_identifier[8];
	uint16_t block_size;
	uint32_t block_count;
	uint32_t FAT_starts;
	uint32_t FAT_blocks;
	uint32_t Root_directory_starts;
	uint32_t Root_directory_blocks;
};

#define DIRECTORY_ENTRY_SIZE 64
#define MAX_ENTRIES_PER_BLOCK 8
int read_directory(FILE *fp, uint32_t start_block, uint32_t num_blocks, uint32_t block_size, DirectoryEntry *entries, int max_entries) {
	//caculate the location of directory
	long offset = (long)start_block * block_size;
	fseek(fp, offset, SEEK_SET);

	int entries_read = 0;	//number of entries already read
	DirectoryEntry temp_entry;

	//read every block
	for (uint32_t i = 0;i < num_blocks && entries_read < max_entries;++i) {
		//read current block into buffer
		unsigned char block_data[block_size];
		if (fread(block_data, block_size, 1, fp) != 1) {
			break;
		}

		//read each entry
		for (int j = 0;j < (block_size / DIRECTORY_ENTRY_SIZE) && entries_read < max_entries;++j) {
			unsigned char *entry_data = block_data + j * DIRECTORY_ENTRY_SIZE;
			DirectoryEntry *entry = &entries[entries_read];

			if (entry_data[0] == 0x03 || entry_data[0] == 0x02) {
				entry->status = 'F';
			} else if (entry_data[0] == 0x04 || entry_data[0] == 0x05) {
				entry->status = 'D';
			} else {
				continue;
			}

			entry->starting_block = ntohl(*(uint32_t *)(entry_data + 1));
			entry->block_count = ntohl(*(uint32_t *)(entry_data + 5));
			entry->file_size = ntohl(*(uint32_t *)(entry_data + 9));

			memcpy(entry->creation_time, entry_data + 13, 7);
			memcpy(entry->file_name, entry_data + 27, 31);
			entries_read++;	
		}
	}

	return entries_read;
}

void parse_hex_creation_time(const unsigned char *hex_time, char *formatted_time) {
	//change hex to dec
	int year = (hex_time[0] << 8) + hex_time[1];
	int month = hex_time[2];
	int day = hex_time[3];
	int hour = hex_time[4];
	int minute = hex_time[5]; 
	int second = hex_time[6];

	sprintf(formatted_time, "%04d-%02d-%02d %02d:%02d:%02d", year, month, day, hour, minute, second);
}

void print_directory_entry(const DirectoryEntry *entry) {
	char formatted_time[20];
	parse_hex_creation_time(entry->creation_time, formatted_time);
	printf("%c %10u %30s %s\n", 
			entry->status, 
			entry->file_size, 
			entry->file_name,
			formatted_time);
}


int main(int argc, char *argv[]) {
	if (argc < 2) {
		fprintf(stderr, "Usage: %s <disk image file> <directory path>\n", argv[0]);
		return 1;
	}

	//extract information of command line
	const char* image_path = argv[1];
	char* dir_path = argv[2];

	//open file
	FILE *fp = fopen(image_path, "rb");
	if (fp == NULL) {
		perror("Error opening disk image");
		return 1;
	}

	struct superblock sb;
	unsigned char buffer[sizeof(struct superblock)];

	//read the superblock
	if (fread(buffer, sizeof(sb), 1, fp) < 1) {
		perror("Error reading superblock");
		fclose(fp);
		return 1;
	}

	//use memcpy to copy the data to struct
	memcpy(sb.filesystem_identifier, buffer, 8);
	memcpy(&sb.block_size, buffer + 8, 2);
	sb.block_size = ntohs(sb.block_size);
	memcpy(&sb.block_count, buffer + 10, sizeof(sb.block_count));
	sb.block_count = ntohl(sb.block_count);
	memcpy(&sb.FAT_starts, buffer + 14, sizeof(sb.FAT_starts));
	sb.FAT_starts = ntohl(sb.FAT_starts);
	memcpy(&sb.FAT_blocks, buffer + 18, sizeof(sb.FAT_blocks));
	sb.FAT_blocks = ntohl(sb.FAT_blocks);
	memcpy(&sb.Root_directory_starts, buffer + 22, sizeof(sb.Root_directory_starts));
	sb.Root_directory_starts = ntohl(sb.Root_directory_starts);
	memcpy(&sb.Root_directory_blocks, buffer + 26, sizeof(sb.Root_directory_blocks));
	sb.Root_directory_blocks = ntohl(sb.Root_directory_blocks);
	
	if (argc == 2){
		//set directory
		DirectoryEntry entries[100];
		int num_entries = read_directory(fp, sb.Root_directory_starts, sb.Root_directory_blocks, sb.block_size, entries, 100);
		//PRINT INFORMATION
		for (int i = 0; i < num_entries; ++i) {
			print_directory_entry(&entries[i]);
		}
	
	} else if (argc == 3) {
		//clear the string of third parameter
		char *cleaned_dir_path = strtok(dir_path, "/");
		
		//set directory
		DirectoryEntry entries[100];
		int num_entries = read_directory(fp, sb.Root_directory_starts, sb.Root_directory_blocks, sb.block_size, entries, 100);	

		//index of the directory we want to open
		int index = -1;
		for (int i = 0; i < num_entries; ++i) {
			if (strcmp(cleaned_dir_path, entries[i].file_name) == 0) {
				index = i;
				break;
			}
		}
		
		//check if we find or not
		if (index == -1) {
			perror("Directory doesn't exist.\n");
			fclose(fp);
			return 1;
		}

		//check if it is a directory
		if (entries[index].status != 'D') {
			perror("It isn't a directory\n");
			fclose(fp);
			return 1;
		}

		//initial the offset
		fseek(fp, 0, SEEK_SET);

		//start to recurse
		DirectoryEntry entry[100];
		int num_search = read_directory(fp, entries[index].starting_block, entries[index].block_count, sb.block_size, entry, 100);
		cleaned_dir_path = strtok(NULL, "/");
		if (cleaned_dir_path == NULL) {
			for (int i = 0; i < num_search; ++i) {
				print_directory_entry(&entry[i]);
			}
			fclose(fp);
			return 0;
		}
		
		//create new array to store the new list.
		DirectoryEntry new_entry[100];
		while (cleaned_dir_path != NULL) {
			//update the index
			index = -1;

			//search the directory the user want
			for (int i = 0; i < num_search; ++i) {
				if (strcmp(cleaned_dir_path, entry[i].file_name) == 0){
					index = i;
					break;
				}
			}

			//check if it find or not
			if (index == -1) {
				//check if it is the last one of the path
				perror("Error opening directory.\n");
				fclose(fp);
				return 1;
			}

			//reset the offset
			fseek(fp, 0, SEEK_SET);

			//recurse opening the list
			int new_num_search = read_directory(fp, entry[index].starting_block, entry[index].block_count, sb.block_size, new_entry, 100);
				
			//update the information which will be uesd in next step
			//get next directory name
			cleaned_dir_path = strtok(NULL,"/");
			num_search = new_num_search;
			memcpy(entry, new_entry, sizeof(new_entry));
			memset(new_entry, 0, sizeof(new_entry));		
		}

		//print the information
		for (int i = 0; i < num_search; ++i) {
			print_directory_entry(&entry[i]);
		}
	
		
			
	}

	fclose(fp);
	return 0;
}
