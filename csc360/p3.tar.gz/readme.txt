README.txt
type 'make' to create output files
In Makefile:

.phony all:
all:
        gcc diskinfo.c -o diskinfo
        gcc disklist.c -o disklist
        gcc diskget.c -o diskget
        gcc diskput.c -o diskput

.PHONY clean:
clean:
        rm diskinfo
        rm disklist
        rm diskget
        rm diskput 

type 'make clean' to clear all the output files.

------------------------------------------------------------------

Program:diskinfo.c

1. Overview
-----------
This program, Disk Image Analyzer, is designed to analyze a disk image file, specifically focusing on reading and displaying the superblock and File Allocation Table (FAT) information. It provides details such as block size, block count, and the number of free, reserved, and allocated blocks.

2. Design
---------
The program is structured into the main function and utilizes the following key concepts:

- File Mapping: Uses memory-mapped files to directly access the disk image in memory.
- Superblock Structure: A packed structure representing the superblock of the file system, containing crucial filesystem parameters.
- FAT Analysis: The program traverses the FAT section to count free, reserved, and allocated blocks.

3. Implementation
------------------
Implemented in C, the program uses standard libraries for file operations, memory mapping, and network byte order conversions. Key aspects include:

- Memory Mapping: The `mmap` function is used to map the contents of a file into the process's address space.
- Superblock Reading: Reads the superblock information from the disk image and displays its content.
- FAT Analysis: Counts different types of blocks (free, reserved, allocated) in the FAT.

-------------------------------------------------------------------------------------------------------------------

Program: disklist.c

1. Overview
-----------
This program is designed to read and display directory information from a specified disk image file. It lists the directory entries, including file status, starting block, block count, file size, creation and modification times, and filenames.

2. Design
---------
The program includes several key components:

- DirectoryEntry Structure: A packed structure representing each directory entry in the disk image.
- Superblock Structure: Defines the layout of the superblock in the disk image, containing crucial filesystem parameters.
- Read Directory Function: Reads the directory entries from the disk image and populates a DirectoryEntry array.
- Parse and Print Functions: Parses hexadecimal time formats and prints the directory entries.

3. Implementation
------------------
Implemented in C, the program leverages standard libraries for file I/O and byte order conversions. The program:

- Reads the superblock to understand the filesystem layout.
- Navigates to the specified directory path within the disk image.
- Processes directory entries and displays their information.
- Handles hierarchical directories and recursive directory parsing.

-------------------------------------------------------------------------------------------------------------------

Program: diskget.c

1. Overview
-----------
This program is designed to read a disk image file, navigate to a specified directory path within it, and extract a file to an output file if found. It handles directory navigation, reads file data, and writes the data to an output file.

2. Design
---------
The program includes several key components:

- DirectoryEntry Structure: A packed structure representing each directory and file entry in the disk image.
- Superblock Structure: Defines the layout of the superblock, which contains crucial filesystem parameters.
- Read Directory Function: Reads the directory entries from the disk image.
- File Extraction Logic: Extracts the specified file from the directory and writes it to an output file.

3. Implementation
------------------
Implemented in C, the program uses standard libraries for file I/O, memory allocation, and byte order conversions. The program:

- Reads and parses the superblock to understand the filesystem layout.
- Navigates to the specified directory path within the disk image.
- Extracts the specified file if found and writes it to an output file.
- Handles errors and edge cases, such as non-existent directories or files.

-------------------------------------------------------------------------------------------------------------------

Program: diskput.c

1. Overview
-----------
This program is designed to perform file system operations on a simulated disk. The main functionality includes reading directories, adding files and subdirectories, and managing file allocation tables within a custom file system structure.

2. Design
---------
The program is structured into several parts:

- Main Function: Serves as the entry point of the program, handling command-line arguments and initiating file system operations.

- File System Structures: Defines several structures (`SuperBlock`, `DirEntry`, `DirEntryTime`, etc.) that represent different aspects of the file system such as directory entries, timestamps, and the superblock.

- Directory Operations: Functions like `read_directory`, `AddEntryToDir`, and `AddSubdirectoryToDir` provide the logic to read directory contents and update the directory structure with new files or subdirectories.

- File Allocation Table (FAT) Management: Handles the allocation and management of blocks within the file system.

3. Implementation
------------------
The program is implemented in C and uses standard libraries for file operations, memory mapping, and string manipulation. Key aspects include:

- File and Directory Handling: Utilizing memory-mapped files for efficient file manipulation and directory entries management.

- Error Handling: Includes checks and error messages to handle potential issues during file operations.

- Memory Management: Uses memory mapping (`mmap`) for direct access to the file system data.

- Network Byte Order Conversion: Functions like `ntohl` and `htonl` are used for handling endianess.

