#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <limits.h>
#include <assert.h>
#include <time.h>

struct __attribute__((__packed__))superblock {
	uint8_t filesystem_identifier[8];
	uint16_t block_size;
	uint32_t block_count;
	uint32_t FAT_starts;
	uint32_t FAT_blocks;
	uint32_t Root_directory_starts;
	uint32_t Root_directory_blocks;
};

int main(int argc, char *argv[]) {
	struct superblock* sb;

	if(argc < 2) {
		fprintf(stderr, "Usage: %s <disk image file>\n",argv[0]);
		return 1;//exit the process
	}

	//open the test.image
	int fd = open(argv[1], O_RDWR);
	struct stat buffer;
	if (fstat(fd, &buffer) < 0) {
		perror("FSTAT ERROR");
		return 1;
	}

	void* map = mmap(NULL, buffer.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	sb = (struct superblock*) map;

	//caculate the start location of FAT
	int FAT_start = ntohs(sb->block_size) * ntohl(sb->FAT_starts);
	//caculate the end of FAT
	int FAT_end = ntohs(sb->block_size) * ntohl(sb->FAT_blocks);

	//caculate the number of blocks in differnt status
	unsigned int Free_blocks = 0, Reserved_blocks = 0, Allocated_blocks = 0;
	for (int i=FAT_start; i < FAT_start + FAT_end; i+=4) {
		uint32_t entry;
		memcpy(&entry, map + i, sizeof(uint32_t));
		entry = ntohl(entry);
		if (entry == 0) {
			++Free_blocks;
		} else if (entry == 1) {
			++Reserved_blocks;
		} else if (entry >= 0x00000002 && entry <= 0xFFFFFF00 || entry == 0xFFFFFFFF) {
			++Allocated_blocks;
		}
	}
	//print the information
	printf("Super block information\n");
	printf("Block size: %d\n", ntohs(sb->block_size));
	printf("Block count: %d\n", ntohl(sb->block_count));
	printf("FAT starts: %d\n", ntohl(sb->FAT_starts));
	printf("FAT blocks: %d\n", ntohl(sb->FAT_blocks));
	printf("Root directory starts: %d\n", ntohl(sb->Root_directory_starts));
	printf("Root directory blocks: %d\n", ntohl(sb->Root_directory_blocks));
	printf("\n");
	printf("FAT information\n");
	printf("Free blocks: %d\n",Free_blocks);
	printf("Reserved blocks: %d\n",Reserved_blocks);
	printf("Allocated blocks: %d\n",Allocated_blocks);
	
	close(fd);

	return 0;
}
